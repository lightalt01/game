# Permission to Relicense under MPLv2

This is a statement by Ericsson
that grants permission to relicense its copyrights in the libzmq C++
library (ZeroMQ) under the Mozilla Public License v2 (MPLv2).

A portion of the commits made by the Github handle "hugne", with
commit author "Erik Hugne erik.hugne@ericsson.com", are copyright of Ericsson.
This document hereby grants the libzmq project team to relicense libzmq,
including all past, present and future contributions of the author listed above.

Jon Maloy <jon.maloy@ericsson.com>
2019/03/27
