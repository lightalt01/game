# Permission to Relicense under MPLv2

This is a statement by Bernd Prager
that grants permission to relicense its copyrights in the libzmq C++
library (ZeroMQ) under the Mozilla Public License v2 (MPLv2).

A portion of the commits made by the Github handle "bprager", with
commit author "Bernd Prager <bernd@prager.ws>", are copyright of Bernd Prager.
This document hereby grants the libzmq project team to relicense libzmq, 
including all past, present and future contributions of the author listed above.

Bernd Prager
2017/03/22
