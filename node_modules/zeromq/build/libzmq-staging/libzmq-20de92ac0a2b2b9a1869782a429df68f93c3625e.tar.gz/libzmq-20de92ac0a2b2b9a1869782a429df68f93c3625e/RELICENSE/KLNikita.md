# Permission to Relicense under MPLv2

This is a statement by Nikita Kozlov
that grants permission to relicense its copyrights in the libzmq C++
library (ZeroMQ) under the Mozilla Public License v2 (MPLv2).

A portion of the commits made by the Github handle "KLNikita", with
commit author "nikita kozlov <nikita@elyzion.net>", are copyright of Nikita Kozlov .
This document hereby grants the libzmq project team to relicense
libzmq,
including all past, present and future contributions of the author
listed above.

Nikita Kozlov
6 February 2020
